const ClientesModule = {
    show() {
        const modal = this.createModal();
        document.getElementById('modalContainer').innerHTML = modal;
        this.loadClientes();
        
        setTimeout(() => {
            document.querySelector('.modal-overlay').classList.add('active');
        }, 10);
    },
    
    createModal() {
        return `
            <div class="modal-overlay" onclick="if(event.target===this)ClientesModule.close()">
                <div class="modal-content" style="max-height: 95vh;">
                    <div class="modal-header">
                        <h2>👥 Clientes</h2>
                        <button class="btn-icon" onclick="ClientesModule.close()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="text" id="buscaCliente" placeholder="🔍 Buscar cliente..." 
                                   onkeyup="ClientesModule.filtrar()">
                        </div>
                        <button onclick="ClientesModule.novoCliente()" class="btn btn-primary btn-block" style="margin-bottom: 20px;">
                            + Novo Cliente
                        </button>
                        <div id="listaClientes"></div>
                    </div>
                </div>
            </div>
        `;
    },
    
    loadClientes() {
        const clientes = DB.getClientes();
        this.renderLista(clientes);
    },
    
    renderLista(clientes) {
        const container = document.getElementById('listaClientes');
        
        if (clientes.length === 0) {
            container.innerHTML = '<p class="empty">Nenhum cliente cadastrado</p>';
            return;
        }
        
        container.innerHTML = clientes.map(c => {
            const plano = DB.getPlanos()[c.plano];
            const percentual = Math.round((c.pecasSemana / (plano?.pecasSemana || 1)) * 100);
            
            return `
                <div class="list-item" onclick="ClientesModule.verDetalhes(${c.id})">
                    <div class="list-avatar">${c.nome.charAt(0)}</div>
                    <div class="list-info">
                        <div class="list-title">${c.nome}</div>
                        <div class="list-subtitle">
                            ${plano?.nome || 'Sem plano'} • ${c.telefone}
                        </div>
                        <div style="margin-top: 8px; font-size: 0.8rem;">
                            <span style="color: ${percentual > 90 ? '#e74c3c' : '#d4af37'}">
                                ${c.pecasSemana}/${plano?.pecasSemana || 0} peças esta semana
                            </span>
                        </div>
                    </div>
                    <span style="color: ${c.statusPagamento === 'pago' ? '#27ae60' : '#e74c3c'}">
                        ${c.statusPagamento === 'pago' ? '✓' : '⚠'}
                    </span>
                </div>
            `;
        }).join('');
    },
    
    filtrar() {
        const termo = document.getElementById('buscaCliente').value.toLowerCase();
        const clientes = DB.getClientes().filter(c => 
            c.nome.toLowerCase().includes(termo) || 
            c.telefone.includes(termo) ||
            c.qrCode.toLowerCase().includes(termo)
        );
        this.renderLista(clientes);
    },
    
    novoCliente() {
        const planos = DB.getPlanos();
        const options = Object.entries(planos).map(([key, p]) => 
            `<option value="${key}">${p.nome} (${p.pecasSemana} peças/semana)</option>`
        ).join('');
        
        const form = `
            <div class="modal-overlay active">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>+ Novo Cliente</h2>
                        <button class="btn-icon" onclick="ClientesModule.show()">✕</button>
                    </div>
                    <div class="modal-body">
                        <form id="formCliente" onsubmit="ClientesModule.salvar(event)">
                            <div class="form-group">
                                <label>Nome Completo *</label>
                                <input type="text" name="nome" required>
                            </div>
                            <div class="form-group">
                                <label>Telefone *</label>
                                <input type="tel" name="telefone" required>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email">
                            </div>
                            <div class="form-group">
                                <label>Endereço</label>
                                <textarea name="endereco" rows="2"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Plano *</label>
                                <select name="plano" required>
                                    ${options}
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Observações</label>
                                <textarea name="observacoes" rows="2"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Salvar Cliente</button>
                        </form>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = form;
    },
    
    salvar(e) {
        e.preventDefault();
        const form = e.target;
        const cliente = {
            nome: form.nome.value,
            telefone: form.telefone.value,
            email: form.email.value,
            endereco: form.endereco.value,
            plano: form.plano.value,
            observacoes: form.observacoes.value
        };
        
        DB.addCliente(cliente);
        this.showToast('Cliente cadastrado com sucesso!');
        this.show();
    },
    
    verDetalhes(id) {
        const c = DB.getClienteById(id);
        const plano = DB.getPlanos()[c.plano];
        const percentual = Math.round((c.pecasSemana / plano.pecasSemana) * 100);
        
        const detalhes = `
            <div class="modal-overlay active">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>👤 ${c.nome}</h2>
                        <button class="btn-icon" onclick="ClientesModule.show()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #d4af37, #f4d03f); 
                                        border-radius: 50%; display: flex; align-items: center; justify-content: center;
                                        font-size: 2rem; margin: 0 auto 10px; color: #0a0a0a; font-weight: 700;">
                                ${c.nome.charAt(0)}
                            </div>
                            <p style="color: #d4af37; font-size: 0.9rem;">${c.qrCode}</p>
                        </div>
                        
                        <div class="info-grid" style="display: grid; gap: 15px; margin-bottom: 20px;">
                            <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                                <label style="color: #888; font-size: 0.8rem;">Plano</label>
                                <p style="color: #d4af37; font-weight: 600;">${plano.nome}</p>
                            </div>
                            <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                                <label style="color: #888; font-size: 0.8rem;">Telefone</label>
                                <p>${c.telefone}</p>
                            </div>
                            <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                                <label style="color: #888; font-size: 0.8rem;">Uso Semanal</label>
                                <p style="color: ${percentual > 90 ? '#e74c3c' : '#27ae60'}; font-weight: 600;">
                                    ${c.pecasSemana}/${plano.pecasSemana} (${percentual}%)
                                </p>
                            </div>
                            <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                                <label style="color: #888; font-size: 0.8rem;">Status Pagamento</label>
                                <p style="color: ${c.statusPagamento === 'pago' ? '#27ae60' : '#e74c3c'}; font-weight: 600;">
                                    ${c.statusPagamento.toUpperCase()}
                                </p>
                            </div>
                        </div>
                        
                        <button onclick="ClientesModule.togglePagamento(${c.id})" class="btn btn-secondary btn-block" style="margin-bottom: 10px;">
                            Alternar Status Pagamento
                        </button>
                        <button onclick="ClientesModule.gerarQR('${c.qrCode}')" class="btn btn-primary btn-block">
                            📷 Ver QR Code
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = detalhes;
    },
    
    togglePagamento(id) {
        const c = DB.getClienteById(id);
        const novoStatus = c.statusPagamento === 'pago' ? 'pendente' : 'pago';
        DB.updateCliente(id, { statusPagamento: novoStatus });
        this.verDetalhes(id);
    },
    
    gerarQR(qr) {
        alert('QR Code: ' + qr + '\n\nUse o scanner para ler este código.');
    },
    
    close() {
        document.querySelector('.modal-overlay').classList.remove('active');
        setTimeout(() => {
            document.getElementById('modalContainer').innerHTML = '';
        }, 300);
    },
    
    showToast(msg) {
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.textContent = msg;
        document.body.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
};
