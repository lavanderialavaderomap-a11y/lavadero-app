const DB = {
    // Inicializar banco
    init() {
        if (!localStorage.getItem('lavadero_db')) {
            const initialData = {
                clientes: [],
                movimentacoes: [],
                configuracoes: {
                    planos: {
                        basico: { nome: 'Básico', pecasSemana: 25, pecasMes: 100, preco: 0 },
                        plus: { nome: 'Plus', pecasSemana: 30, pecasMes: 120, preco: 0 },
                        premium: { nome: 'Premium', pecasSemana: 35, pecasMes: 140, preco: 0 }
                    }
                },
                ultimoId: 0
            };
            this.save(initialData);
        }
    },
    
    // Obter dados
    get() {
        return JSON.parse(localStorage.getItem('lavadero_db')) || {};
    },
    
    // Salvar dados
    save(data) {
        localStorage.setItem('lavadero_db', JSON.stringify(data));
    },
    
    // Gerar ID único
    generateId() {
        const data = this.get();
        data.ultimoId = (data.ultimoId || 0) + 1;
        this.save(data);
        return data.ultimoId;
    },
    
    // CLIENTES
    addCliente(cliente) {
        const data = this.get();
        cliente.id = this.generateId();
        cliente.qrCode = 'LAV-' + Date.now().toString(36).toUpperCase();
        cliente.dataCadastro = new Date().toISOString();
        cliente.ativo = true;
        cliente.pecasSemana = 0;
        cliente.pecasMes = 0;
        cliente.semanaAtual = this.getSemanaAtual();
        cliente.statusPagamento = 'pago';
        
        data.clientes.push(cliente);
        this.save(data);
        return cliente;
    },
    
    getClientes() {
        return this.get().clientes || [];
    },
    
    getClienteById(id) {
        return this.getClientes().find(c => c.id === id);
    },
    
    getClienteByQR(qr) {
        return this.getClientes().find(c => c.qrCode === qr);
    },
    
    updateCliente(id, updates) {
        const data = this.get();
        const index = data.clientes.findIndex(c => c.id === id);
        if (index !== -1) {
            data.clientes[index] = { ...data.clientes[index], ...updates };
            this.save(data);
            return data.clientes[index];
        }
        return null;
    },
    
    // Verificar e resetar limites semanais
    verificarLimites() {
        const data = this.get();
        const semanaAtual = this.getSemanaAtual();
        
        data.clientes.forEach(cliente => {
            if (cliente.semanaAtual !== semanaAtual) {
                cliente.semanaAtual = semanaAtual;
                cliente.pecasSemana = 0;
            }
        });
        
        this.save(data);
    },
    
    getSemanaAtual() {
        const now = new Date();
        const start = new Date(now.getFullYear(), 0, 1);
        const diff = now - start;
        return Math.floor(diff / (7 * 24 * 60 * 60 * 1000));
    },
    
    // MOVIMENTAÇÕES
    addMovimentacao(mov) {
        const data = this.get();
        mov.id = this.generateId();
        mov.data = new Date().toISOString();
        mov.dataHora = new Date().toLocaleString('pt-BR');
        
        data.movimentacoes.push(mov);
        this.save(data);
        
        // Atualizar contador do cliente
        this.atualizarPecasCliente(mov.clienteId, mov.quantidade);
        
        return mov;
    },
    
    atualizarPecasCliente(clienteId, quantidade) {
        const cliente = this.getClienteById(clienteId);
        if (cliente) {
            cliente.pecasSemana += quantidade;
            cliente.pecasMes += quantidade;
            this.updateCliente(clienteId, cliente);
        }
    },
    
    getMovimentacoes(filtros = {}) {
        let movs = this.get().movimentacoes || [];
        
        if (filtros.hoje) {
            const hoje = new Date().toISOString().split('T')[0];
            movs = movs.filter(m => m.data.startsWith(hoje));
        }
        
        if (filtros.status) {
            movs = movs.filter(m => m.status === filtros.status);
        }
        
        if (filtros.clienteId) {
            movs = movs.filter(m => m.clienteId === filtros.clienteId);
        }
        
        return movs.sort((a, b) => new Date(b.data) - new Date(a.data));
    },
    
    updateMovimentacaoStatus(id, novoStatus) {
        const data = this.get();
        const index = data.movimentacoes.findIndex(m => m.id === id);
        if (index !== -1) {
            data.movimentacoes[index].status = novoStatus;
            data.movimentacoes[index].historicoStatus = data.movimentacoes[index].historicoStatus || [];
            data.movimentacoes[index].historicoStatus.push({
                status: novoStatus,
                data: new Date().toLocaleString('pt-BR')
            });
            this.save(data);
            return data.movimentacoes[index];
        }
        return null;
    },
    
    // ESTATÍSTICAS
    getStats() {
        const clientes = this.getClientes();
        const movs = this.getMovimentacoes();
        const hoje = this.getMovimentacoes({ hoje: true });
        
        return {
            totalClientes: clientes.filter(c => c.ativo).length,
            producaoDia: hoje.reduce((sum, m) => sum + (m.quantidade || 0), 0),
            emLavagem: movs.filter(m => m.status === 'lavando').length,
            emSecagem: movs.filter(m => m.status === 'secando').length,
            finalizados: movs.filter(m => m.status === 'finalizado').length,
            pendentes: clientes.filter(c => c.statusPagamento === 'pendente').length
        };
    },
    
    getStatusCounts() {
        const movs = this.getMovimentacoes();
        const counts = { recebido: 0, lavando: 0, secando: 0, passando: 0, finalizado: 0, entregue: 0 };
        movs.forEach(m => {
            if (counts[m.status] !== undefined) counts[m.status]++;
        });
        return counts;
    },
    
    getAlertasLimite() {
        this.verificarLimites();
        const clientes = this.getClientes();
        const alertas = [];
        
        clientes.forEach(c => {
            const plano = this.get().configuracoes.planos[c.plano];
            if (plano && c.pecasSemana >= plano.pecasSemana * 0.8) {
                alertas.push({
                    cliente: c.nome,
                    plano: plano.nome,
                    usado: c.pecasSemana,
                    limite: plano.pecasSemana,
                    percentual: Math.round((c.pecasSemana / plano.pecasSemana) * 100)
                });
            }
        });
        
        return alertas;
    },
    
    // PLANOS
    getPlanos() {
        return this.get().configuracoes.planos;
    },
    
    verificarLimiteCliente(clienteId, quantidade) {
        const cliente = this.getClienteById(clienteId);
        if (!cliente) return { permitido: false, mensagem: 'Cliente não encontrado' };
        
        const plano = this.getPlanos()[cliente.plano];
        if (!plano) return { permitido: false, mensagem: 'Plano não encontrado' };
        
        if (cliente.pecasSemana + quantidade > plano.pecasSemana) {
            return {
                permitido: false,
                mensagem: `Limite semanal excedido! ${cliente.pecasSemana}/${plano.pecasSemana} peças`
            };
        }
        
        return { permitido: true };
    }
};
