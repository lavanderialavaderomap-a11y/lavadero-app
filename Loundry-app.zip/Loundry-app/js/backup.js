const BackupModule = {
    show() {
        const modal = `
            <div class="modal-overlay active">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>💾 Backup & Restauração</h2>
                        <button class="btn-icon" onclick="BackupModule.close()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div style="background: rgba(39, 174, 96, 0.1); border: 1px solid rgba(39, 174, 96, 0.3); 
                                    border-radius: 16px; padding: 20px; margin-bottom: 20px;">
                            <h3 style="color: #27ae60; margin-bottom: 10px;">📤 Exportar Dados</h3>
                            <p style="color: #888; font-size: 0.9rem; margin-bottom: 15px;">
                                Salve todos os clientes, movimentações e configurações em um arquivo JSON.
                            </p>
                            <button onclick="BackupModule.exportar()" class="btn btn-primary btn-block">
                                Exportar Backup
                            </button>
                        </div>
                        
                        <div style="background: rgba(52, 152, 219, 0.1); border: 1px solid rgba(52, 152, 219, 0.3); 
                                    border-radius: 16px; padding: 20px; margin-bottom: 20px;">
                            <h3 style="color: #3498db; margin-bottom: 10px;">📥 Importar Dados</h3>
                            <p style="color: #888; font-size: 0.9rem; margin-bottom: 15px;">
                                Restaure dados de um arquivo de backup anterior.
                            </p>
                            <input type="file" id="fileImport" accept=".json" onchange="BackupModule.importar(this)" 
                                   style="display: none;">
                            <button onclick="document.getElementById('fileImport').click()" class="btn btn-secondary btn-block">
                                Selecionar Arquivo
                            </button>
                        </div>
                        
                        <div style="background: rgba(231, 76, 60, 0.1); border: 1px solid rgba(231, 76, 60, 0.3); 
                                    border-radius: 16px; padding: 20px;">
                            <h3 style="color: #e74c3c; margin-bottom: 10px;">⚠️ Resetar Sistema</h3>
                            <p style="color: #888; font-size: 0.9rem; margin-bottom: 15px;">
                                Apaga TODOS os dados. Esta ação não pode ser desfeita!
                            </p>
                            <button onclick="BackupModule.reset()" class="btn btn-danger btn-block">
                                Resetar (Senha necessária)
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = modal;
    },
    
    exportar() {
        const data = DB.get();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `lavadero-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        alert('✅ Backup exportado com sucesso!');
    },
    
    importar(input) {
        const file = input.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                
                if (confirm('⚠️ Isso substituirá todos os dados atuais. Deseja continuar?')) {
                    DB.save(data);
                    alert('✅ Dados importados com sucesso!');
                    location.reload();
                }
            } catch (err) {
                alert('❌ Erro ao importar: arquivo inválido');
            }
        };
        reader.readAsText(file);
    },
    
    reset() {
        const senha = prompt('Digite a senha de administrador para confirmar:');
        
        const users = JSON.parse(localStorage.getItem('lavadero_users')) || [];
        const admin = users.find(u => u.username === 'admin');
        
        if (senha === admin?.password) {
            if (confirm('⚠️ TODOS os dados serão apagados. Confirma?')) {
                localStorage.removeItem('lavadero_db');
                alert('Sistema resetado. Recarregando...');
                location.reload();
            }
        } else {
            alert('❌ Senha incorreta!');
        }
    },
    
    close() {
        document.querySelector('.modal-overlay')?.classList.remove('active');
        setTimeout(() => {
            document.getElementById('modalContainer').innerHTML = '';
        }, 300);
    }
};
