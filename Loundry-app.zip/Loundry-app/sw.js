const CACHE_NAME = 'lavadero-v1';
const urlsToCache = [
  './',
  './index.html',
  './login.html',
  './dashboard.html',
  './css/style.css',
  './js/auth.js',
  './js/db.js',
  './js/clientes.js',
  './js/planos.js',
  './js/scanner.js',
  './js/producao.js',
  './js/status.js',
  './js/backup.js',
  'https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          return response;
        }
        return fetch(event.request);
      })
  );
});
