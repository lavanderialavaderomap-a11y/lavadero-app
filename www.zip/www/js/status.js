const StatusModule = {
    show() {
        const modal = `
            <div class="modal-overlay active">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>📋 Status Completo</h2>
                        <button class="btn-icon" onclick="StatusModule.close()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="text" id="buscaStatus" placeholder="🔍 Buscar..." 
                                   onkeyup="StatusModule.filtrar()">
                        </div>
                        <div id="listaStatus"></div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = modal;
        this.loadStatus();
    },
    
    loadStatus() {
        const movs = DB.getMovimentacoes();
        this.renderLista(movs);
    },
    
    renderLista(movs) {
        const container = document.getElementById('listaStatus');
        
        if (movs.length === 0) {
            container.innerHTML = '<p class="empty">Nenhuma movimentação</p>';
            return;
        }
        
        container.innerHTML = movs.map(m => {
            const cliente = DB.getClienteById(m.clienteId);
            const statusColors = {
                'recebido': '#888',
                'lavando': '#3498db',
                'secando': '#f39c12',
                'passando': '#9b59b6',
                'finalizado': '#27ae60',
                'entregue': '#27ae60'
            };
            
            return `
                <div class="list-item" style="border-left: 4px solid ${statusColors[m.status] || '#888'};">
                    <div class="list-info">
                        <div class="list-title" style="display: flex; justify-content: space-between;">
                            <span>${cliente?.nome || 'Desconhecido'}</span>
                            <span style="color: ${statusColors[m.status]}; font-size: 0.8rem; text-transform: uppercase;">
                                ${m.status}
                            </span>
                        </div>
                        <div class="list-subtitle">
                            #${m.id} • ${m.quantidade} peças • ${m.dataHora}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    },
    
    filtrar() {
        const termo = document.getElementById('buscaStatus').value.toLowerCase();
        const movs = DB.getMovimentacoes().filter(m => {
            const cliente = DB.getClienteById(m.clienteId);
            return cliente?.nome.toLowerCase().includes(termo) ||
                   m.id.toString().includes(termo) ||
                   m.status.includes(termo);
        });
        this.renderLista(movs);
    },
    
    close() {
        document.querySelector('.modal-overlay')?.classList.remove('active');
        setTimeout(() => {
            document.getElementById('modalContainer').innerHTML = '';
        }, 300);
    }
};
