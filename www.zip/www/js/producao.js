const ProducaoModule = {
    show() {
        const modal = `
            <div class="modal-overlay active">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>⚙️ Painel de Produção</h2>
                        <button class="btn-icon" onclick="ProducaoModule.close()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div class="producao-grid" id="producaoGrid">
                            ${this.renderKanban()}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = modal;
        this.loadProducao();
    },
    
    renderKanban() {
        const statusList = [
            { id: 'recebido', nome: 'Recebido', icon: '📥', cor: '#888' },
            { id: 'lavando', nome: 'Lavando', icon: '🧼', cor: '#3498db' },
            { id: 'secando', nome: 'Secando', icon: '💨', cor: '#f39c12' },
            { id: 'passando', nome: 'Passando', icon: '🔥', cor: '#9b59b6' },
            { id: 'finalizado', nome: 'Finalizado', icon: '✅', cor: '#27ae60' }
        ];
        
        return statusList.map(s => `
            <div class="kanban-column" style="margin-bottom: 20px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid ${s.cor};">
                    <span style="font-size: 1.5rem;">${s.icon}</span>
                    <span style="font-weight: 600; color: ${s.cor};">${s.nome}</span>
                    <span class="badge" id="badge-${s.id}" style="background: ${s.cor}; color: white; padding: 2px 10px; border-radius: 10px; font-size: 0.8rem; margin-left: auto;">0</span>
                </div>
                <div id="coluna-${s.id}" class="kanban-items" style="min-height: 100px;">
                    <p class="empty" style="color: #555; text-align: center; padding: 20px;">Carregando...</p>
                </div>
            </div>
        `).join('');
    },
    
    loadProducao() {
        const movs = DB.getMovimentacoes().filter(m => m.status !== 'entregue');
        const statusList = ['recebido', 'lavando', 'secando', 'passando', 'finalizado'];
        
        statusList.forEach(status => {
            const items = movs.filter(m => m.status === status);
            const container = document.getElementById(`coluna-${status}`);
            const badge = document.getElementById(`badge-${status}`);
            
            badge.textContent = items.length;
            
            if (items.length === 0) {
                container.innerHTML = '<p class="empty" style="color: #555; text-align: center; padding: 20px;">Nenhum item</p>';
            } else {
                container.innerHTML = items.map(m => {
                    const cliente = DB.getClienteById(m.clienteId);
                    return `
                        <div class="producao-card" onclick="ProducaoModule.verDetalhes(${m.id})" 
                             style="background: rgba(255,255,255,0.03); border: 1px solid rgba(212,175,55,0.2); 
                                    border-radius: 12px; padding: 15px; margin-bottom: 10px; cursor: pointer;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                <span style="font-weight: 600; color: #d4af37;">#${m.id}</span>
                                <span style="font-size: 0.8rem; color: #888;">${m.dataHora.split(' ')[0]}</span>
                            </div>
                            <p style="margin-bottom: 5px;">${cliente?.nome || 'Desconhecido'}</p>
                            <p style="font-size: 0.85rem; color: #888;">${m.quantidade} peças • ${m.tipoPecas}</p>
                        </div>
                    `;
                }).join('');
            }
        });
    },
    
    verDetalhes(movId) {
        const mov = DB.getMovimentacoes().find(m => m.id === movId);
        const cliente = DB.getClienteById(mov.clienteId);
        
        const proximosStatus = {
            'recebido': 'lavando',
            'lavando': 'secando',
            'secando': 'passando',
            'passando': 'finalizado',
            'finalizado': 'entregue'
        };
        
        const nomesStatus = {
            'recebido': 'Recebido',
            'lavando': 'Lavando',
            'secando': 'Secando',
            'passando': 'Passando',
            'finalizado': 'Finalizado',
            'entregue': 'Entregue'
        };
        
        const detalhes = `
            <div class="modal-overlay active">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>#${mov.id} - ${cliente.nome}</h2>
                        <button class="btn-icon" onclick="ProducaoModule.show()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div style="background: rgba(212,175,55,0.1); padding: 20px; border-radius: 16px; margin-bottom: 20px;">
                            <p><strong>Status Atual:</strong> <span style="color: #d4af37; font-size: 1.2rem;">${nomesStatus[mov.status]}</span></p>
                            <p><strong>Quantidade:</strong> ${mov.quantidade} peças</p>
                            <p><strong>Tipo:</strong> ${mov.tipoPecas}</p>
                            <p><strong>Entrada:</strong> ${mov.dataHora}</p>
                            ${mov.observacoes ? `<p><strong>Obs:</strong> ${mov.observacoes}</p>` : ''}
                        </div>
                        
                        ${mov.status !== 'entregue' ? `
                            <button onclick="ProducaoModule.avancarStatus(${mov.id}, '${proximosStatus[mov.status]}')" 
                                    class="btn btn-primary btn-block" style="margin-bottom: 10px;">
                                → Avançar para: ${nomesStatus[proximosStatus[mov.status]]}
                            </button>
                        ` : '<p style="text-align: center; color: #27ae60; font-size: 1.2rem;">✓ Entregue</p>'}
                        
                        <button onclick="ProducaoModule.show()" class="btn btn-secondary btn-block">Voltar</button>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = detalhes;
    },
    
    avancarStatus(movId, novoStatus) {
        DB.updateMovimentacaoStatus(movId, novoStatus);
        
        if (novoStatus === 'entregue') {
            alert('✅ Item marcado como entregue!');
        } else {
            this.showToast(`Status atualizado: ${novoStatus}`);
        }
        
        this.show();
    },
    
    showToast(msg) {
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.textContent = msg;
        document.body.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 2000);
    },
    
    close() {
        document.querySelector('.modal-overlay')?.classList.remove('active');
        setTimeout(() => {
            document.getElementById('modalContainer').innerHTML = '';
        }, 300);
    }
};
