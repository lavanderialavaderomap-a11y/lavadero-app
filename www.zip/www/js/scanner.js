const ScannerModule = {
    html5QrCode: null,
    
    show() {
        const modal = `
            <div class="modal-overlay active">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>📷 Scanner QR</h2>
                        <button class="btn-icon" onclick="ScannerModule.close()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div id="reader" style="width: 100%; height: 400px; border-radius: 16px; overflow: hidden;"></div>
                        <div style="text-align: center; margin-top: 15px;">
                            <p style="color: #888; font-size: 0.9rem;">Posicione o QR Code do cliente</p>
                        </div>
                        <div style="display: flex; gap: 10px; margin-top: 20px;">
                            <input type="text" id="qrManual" placeholder="Ou digite o código..." 
                                   style="flex: 1; padding: 15px; background: rgba(0,0,0,0.3); border: 1px solid rgba(212,175,55,0.3); 
                                          border-radius: 12px; color: #fff;">
                            <button onclick="ScannerModule.lerManual()" class="btn btn-primary">OK</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = modal;
        this.iniciarCamera();
    },
    
    async iniciarCamera() {
        try {
            this.html5QrCode = new Html5Qrcode("reader");
            await this.html5QrCode.start(
                { facingMode: "environment" },
                { fps: 10, qrbox: { width: 250, height: 250 } },
                (decodedText) => {
                    this.processarQR(decodedText);
                },
                (error) => {}
            );
        } catch (err) {
            console.error('Erro na câmera:', err);
            document.getElementById('reader').innerHTML = `
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #e74c3c;">
                    Erro ao acessar câmera. Use a entrada manual.
                </div>
            `;
        }
    },
    
    async pararCamera() {
        if (this.html5QrCode) {
            try {
                await this.html5QrCode.stop();
            } catch (e) {}
            this.html5QrCode = null;
        }
    },
    
    lerManual() {
        const qr = document.getElementById('qrManual').value.trim();
        if (qr) this.processarQR(qr);
    },
    
    processarQR(qrCode) {
        this.pararCamera();
        
        const cliente = DB.getClienteByQR(qrCode);
        
        if (!cliente) {
            alert('Cliente não encontrado! Verifique o código ou cadastre o cliente.');
            this.show();
            return;
        }
        
        this.mostrarRegistroEntrada(cliente);
    },
    
    mostrarRegistroEntrada(cliente) {
        const plano = DB.getPlanos()[cliente.plano];
        
        const form = `
            <div class="modal-overlay active">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>📥 Registrar Entrada</h2>
                        <button class="btn-icon" onclick="ScannerModule.close()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div style="background: rgba(212,175,55,0.1); padding: 20px; border-radius: 16px; margin-bottom: 20px;">
                            <h3 style="color: #d4af37; margin-bottom: 5px;">${cliente.nome}</h3>
                            <p style="color: #888; font-size: 0.9rem;">${plano.nome} • ${cliente.pecasSemana}/${plano.pecasSemana} peças</p>
                        </div>
                        
                        <form onsubmit="ScannerModule.registrarEntrada(event, ${cliente.id})">
                            <div class="form-group">
                                <label>Quantidade de Peças *</label>
                                <input type="number" id="qtdPecas" min="1" max="50" required 
                                       onchange="ScannerModule.verificarLimite(${cliente.id}, this.value)">
                                <p id="limiteMsg" style="color: #e74c3c; font-size: 0.85rem; margin-top: 5px; display: none;"></p>
                            </div>
                            
                            <div class="form-group">
                                <label>Tipo de Peças</label>
                                <select id="tipoPecas">
                                    <option value="roupas">Roupas do dia a dia</option>
                                    <option value="cama">Cama/Mesa/Banho</option>
                                    <option value="especiais">Peças Especiais</option>
                                    <option value="misturado">Misturado</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Observações</label>
                                <textarea id="obsEntrada" rows="2" placeholder="Manchas, cuidados especiais..."></textarea>
                            </div>
                            
                            <button type="submit" id="btnRegistrar" class="btn btn-primary btn-block">
                                Registrar Entrada
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = form;
    },
    
    verificarLimite(clienteId, quantidade) {
        const resultado = DB.verificarLimiteCliente(clienteId, parseInt(quantidade));
        const msgEl = document.getElementById('limiteMsg');
        const btn = document.getElementById('btnRegistrar');
        
        if (!resultado.permitido) {
            msgEl.textContent = resultado.mensagem;
            msgEl.style.display = 'block';
            btn.style.opacity = '0.5';
            btn.disabled = true;
        } else {
            msgEl.style.display = 'none';
            btn.style.opacity = '1';
            btn.disabled = false;
        }
    },
    
    registrarEntrada(e, clienteId) {
        e.preventDefault();
        
        const qtd = parseInt(document.getElementById('qtdPecas').value);
        const tipo = document.getElementById('tipoPecas').value;
        const obs = document.getElementById('obsEntrada').value;
        
        const mov = {
            clienteId: clienteId,
            tipo: 'entrada',
            quantidade: qtd,
            tipoPecas: tipo,
            observacoes: obs,
            status: 'recebido'
        };
        
        DB.addMovimentacao(mov);
        
        alert(`✅ Entrada registrada!\n\n${qtd} peças recebidas.\nStatus: Recebido`);
        this.close();
    },
    
    close() {
        this.pararCamera();
        document.querySelector('.modal-overlay')?.classList.remove('active');
        setTimeout(() => {
            document.getElementById('modalContainer').innerHTML = '';
        }, 300);
    }
};
