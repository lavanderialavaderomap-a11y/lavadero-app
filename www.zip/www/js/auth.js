const Auth = {
    SESSION_KEY: 'lavadero_session',
    SESSION_DURATION: 8 * 60 * 60 * 1000, // 8 horas
    
    login(username, password) {
        const users = JSON.parse(localStorage.getItem('lavadero_users')) || [];
        const user = users.find(u => u.username === username && u.password === password);
        
        if (user) {
            const session = {
                username: user.username,
                name: user.name,
                role: user.role,
                loginTime: Date.now()
            };
            localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));
            return true;
        }
        return false;
    },
    
    checkSession() {
        const session = this.getSession();
        if (!session) return false;
        
        const now = Date.now();
        if (now - session.loginTime > this.SESSION_DURATION) {
            this.logout();
            return false;
        }
        
        // Renovar sessão
        session.loginTime = now;
        localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));
        return true;
    },
    
    getSession() {
        const session = localStorage.getItem(this.SESSION_KEY);
        return session ? JSON.parse(session) : null;
    },
    
    logout() {
        localStorage.removeItem(this.SESSION_KEY);
        window.location.href = 'login.html';
    },
    
    isAdmin() {
        const session = this.getSession();
        return session && session.role === 'admin';
    }
};
